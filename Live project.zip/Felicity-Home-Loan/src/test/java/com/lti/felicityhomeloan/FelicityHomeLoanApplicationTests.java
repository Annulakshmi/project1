package com.lti.felicityhomeloan;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase.Replace;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.lti.felicityhomeloan.GenericDao.HomeLoanDao;
import com.lti.felicityhomeloan.GenericDao.LoanDetailsDao;
import com.lti.felicityhomeloan.entity.LoanDetails;
import com.lti.felicityhomeloan.entity.PersonalDetails;

@RunWith(SpringRunner.class)
@SpringBootTest
@AutoConfigureTestDatabase(replace=Replace.NONE)
public class FelicityHomeLoanApplicationTests {

	@Autowired
	//private HomeLoanDao homeLoanDao;
	private LoanDetailsDao loandetailsDao;
	
	@Test
	public void contextLoads() {
		/*PersonalDetails personalDetails = new PersonalDetails();
		personalDetails.setFirstname("Kolama");
		personalDetails.setMiddlename("Ramya");
		personalDetails.setLastname("Priya");
		personalDetails.setEmail_id("ramyapriya@gmai.com");
		personalDetails.setPassword("ramya@K3");
		personalDetails.setConform_password("ramya@K3");
		personalDetails.setPhonenumber("9239048534");
		personalDetails.setBirthdate("10-10-1997");
		personalDetails.setGender("F");
		personalDetails.setNationality("Indian");
		personalDetails.setAdharnumber("37837298");
		personalDetails.setPannumber("JPSL6666");
		
	    homeLoanDao.add(personalDetails); */
		
		LoanDetails loanDetails= new LoanDetails();
		loanDetails.setMaxamtgrantable(1000000);
		loanDetails.setRateofinterest(8.5);
		loanDetails.setTenure(12);
		loanDetails.setLoanamt(500000);
		
		loandetailsDao.add(loanDetails);
		
	}

}

