package com.lti.felicityhomeloan.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.lti.felicityhomeloan.entity.LoanDetails;
import com.lti.felicityhomeloan.entity.PersonalDetails;
import com.lti.felicityhomeloan.service.LoanDetailsService;

@RestController
@CrossOrigin
public class LoanDetailsController {
	
	@Autowired
	private LoanDetailsService loandetailsservice;
	
	@RequestMapping(path="/loandetails/add",method = RequestMethod.POST)
	public String add(@RequestBody LoanDetails loandetails) {
		loandetailsservice.add(loandetails);
		return "details are successfully added";
	}
}
