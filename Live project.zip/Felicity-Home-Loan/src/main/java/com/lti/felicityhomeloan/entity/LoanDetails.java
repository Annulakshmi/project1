package com.lti.felicityhomeloan.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="LOAN_DETAILS")
public class LoanDetails {
	
	@Id
	private int applicationId;
	public int getApplicationId() {
		return applicationId;
	}
	public void setApplicationId(int applicationId) {
		this.applicationId = applicationId;
	}
	@Column(name="max_amt_grantable")
	private double maxamtgrantable;
	private double rateofinterest;
	private int tenure;
	private double loanamt;
	
	public double getMaxamtgrantable() {
		return maxamtgrantable;
	}
	public void setMaxamtgrantable(double maxamtgrantable) {
		this.maxamtgrantable = maxamtgrantable;
	}
	public double getRateofinterest() {
		return rateofinterest;
	}
	public void setRateofinterest(double d) {
		this.rateofinterest = d;
	}
	public int getTenure() {
		return tenure;
	}
	public void setTenure(int tenure) {
		this.tenure = tenure;
	}
	public double getLoanamt() {
		return loanamt;
	}
	public void setLoanamt(double loanamt) {
		this.loanamt = loanamt;
	}
	
	
	
}
