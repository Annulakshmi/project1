package com.lti.felicityhomeloan.GenericDao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.lti.felicityhomeloan.entity.PersonalDetails;

@Repository
public class HomeLoanDao {

	@PersistenceContext
	private EntityManager entityManager;

	@Transactional
	public void add( PersonalDetails details) {
		
		entityManager.persist(details);
		
	}
	
	public PersonalDetails fetch(int applicationid) {
		return entityManager.find(PersonalDetails.class,applicationid);
	}
}
