package com.lti.felicityhomeloan.GenericDao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.lti.felicityhomeloan.entity.LoanDetails;

@Repository
public class LoanDetailsDao {
	
	@PersistenceContext
	private EntityManager entityManager;
	
	@Transactional
	public void add( LoanDetails loandetails) {
		entityManager.persist(loandetails);
		
	}
}
