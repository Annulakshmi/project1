package com.lti.felicityhomeloan.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.lti.felicityhomeloan.GenericDao.HomeLoanDao;
import com.lti.felicityhomeloan.entity.PersonalDetails;

@Service
public class HomeLoanService {

	@Autowired
	private HomeLoanDao homeloandao;
	
	@Transactional
	public void add(PersonalDetails details) {
		  homeloandao.add(details);
	}
	
	public PersonalDetails fetch(int applicationid) {
		return homeloandao.fetch(applicationid);
	}
}
