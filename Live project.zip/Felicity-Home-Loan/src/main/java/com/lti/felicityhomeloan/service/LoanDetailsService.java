package com.lti.felicityhomeloan.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lti.felicityhomeloan.GenericDao.LoanDetailsDao;
import com.lti.felicityhomeloan.entity.LoanDetails;
import com.lti.felicityhomeloan.entity.PersonalDetails;

@Service
public class LoanDetailsService {
	
	@Autowired
	private LoanDetailsDao loandetailsdao;
	
	@Transactional
	public void add(LoanDetails loandetails) {
		loandetailsdao.add(loandetails);
	}

}
