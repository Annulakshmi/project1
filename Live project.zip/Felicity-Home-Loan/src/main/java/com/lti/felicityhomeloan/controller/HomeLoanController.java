package com.lti.felicityhomeloan.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.lti.felicityhomeloan.entity.PersonalDetails;
import com.lti.felicityhomeloan.service.HomeLoanService;



@RestController
@CrossOrigin
public class HomeLoanController {
	
	@Autowired
	private HomeLoanService homeloanservice;
	
	@RequestMapping(path="/details/add",method = RequestMethod.POST)
	public String add(@RequestBody PersonalDetails details) {
		homeloanservice.add(details);
		return "details are added";
		
	}
		
	@RequestMapping(path = "/details/{applicationid}", method = RequestMethod.GET)
		public PersonalDetails fetch(@PathVariable("applicationid") int applicationid)  {
			return homeloanservice.fetch(applicationid);
		}
	
	
	
	
}
