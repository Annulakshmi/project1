package com.lti.felicityhomeloan;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FelicityHomeLoanApplication {

	public static void main(String[] args) {
		SpringApplication.run(FelicityHomeLoanApplication.class, args);
	}

}

